# 🚀 Complete Setup Guide: Run Bitcoin Prediction on Your Laptop

## Step-by-Step Instructions for Beginners

---

## PART 1: Download & Install Required Software

### 1.1 Install Python (The Programming Language)

1. Go to: **https://www.python.org/downloads/**
2. Click the big yellow button: **"Download Python 3.12.x"**
3. Run the downloaded file
4. ⚠️ **IMPORTANT**: Check the box that says **"Add Python to PATH"** at the bottom!
5. Click "Install Now"
6. Wait for installation to complete
7. Click "Close"

**To verify Python is installed:**
- Press `Windows + R`
- Type `cmd` and press Enter
- Type: `python --version`
- You should see: `Python 3.12.x`

---

### 1.2 Install Visual Studio Code (The Code Editor)

1. Go to: **https://code.visualstudio.com/**
2. Click **"Download for Windows"** (or Mac)
3. Run the downloaded file
4. Click "Next" through all steps
5. ✅ Check "Add to PATH"
6. ✅ Check "Create a desktop icon"
7. Click "Install"
8. Click "Finish"

---

### 1.3 Install Python Extension in VS Code

1. Open Visual Studio Code
2. Click the **Extensions icon** on the left sidebar (looks like 4 squares)
3. Search for: **"Python"**
4. Click on "Python" by Microsoft
5. Click the blue **"Install"** button
6. Wait for it to install

---

## PART 2: Create Your Project Folder

### 2.1 Create a Folder on Your Computer

1. Open File Explorer
2. Go to your Documents folder (or Desktop)
3. Right-click → New → Folder
4. Name it: **bitcoin-prediction**

---

### 2.2 Open the Folder in VS Code

1. Open Visual Studio Code
2. Click **File** → **Open Folder**
3. Navigate to your **bitcoin-prediction** folder
4. Click **"Select Folder"**
5. If asked "Do you trust the authors?" → Click **"Yes, I trust"**

---

## PART 3: Download Project Files

### 3.1 Get Files from Claude

Download all the files I gave you and save them in your **bitcoin-prediction** folder:

```
bitcoin-prediction/
├── step1_data_collection.py
├── step2_eda.py
├── step3_feature_engineering.py
├── step4_models.py
├── Bitcoin_Price_Prediction.ipynb
└── README.md
```

---

## PART 4: Install Python Libraries

### 4.1 Open Terminal in VS Code

1. In VS Code, click **Terminal** → **New Terminal** (at the top menu)
2. A terminal window will open at the bottom of VS Code

### 4.2 Install Required Libraries

Copy and paste this command into the terminal and press Enter:

```bash
pip install pandas numpy matplotlib seaborn scikit-learn xgboost prophet statsmodels yfinance
```

**What each library does:**
| Library | Purpose |
|---------|---------|
| pandas | Work with data tables |
| numpy | Math calculations |
| matplotlib | Create charts |
| seaborn | Pretty charts |
| scikit-learn | Machine learning |
| xgboost | XGBoost model |
| prophet | Facebook's forecasting |
| statsmodels | ARIMA model |
| yfinance | Download Bitcoin data |

⏳ This will take 2-5 minutes. Wait until you see no more text appearing.

**If you see errors**, try this instead:
```bash
pip install pandas numpy matplotlib seaborn scikit-learn xgboost statsmodels yfinance
pip install prophet
```

---

## PART 5: Run the Project!

### 5.1 Run Step 1: Data Collection

1. In VS Code, click on **step1_data_collection.py** in the left sidebar
2. You'll see the code open in the editor
3. Click the **▶️ Play button** in the top-right corner
   - OR press **Ctrl + F5** (Windows) / **Cmd + F5** (Mac)
   - OR right-click and select "Run Python File in Terminal"

4. Watch the terminal - you'll see output like:
```
============================================================
STEP 1: BITCOIN DATA COLLECTION
============================================================
📥 Downloading Bitcoin historical data...
✅ Downloaded 1828 days of Bitcoin data
```

5. A new file **bitcoin_data.csv** will appear in your folder!

---

### 5.2 Run Step 2: EDA

1. Click on **step2_eda.py**
2. Click the **▶️ Play button**
3. Wait for it to complete
4. New files created:
   - **eda_analysis.png** (price charts)
   - **correlation_heatmap.png** (correlation matrix)
   - **bitcoin_data_processed.csv**

**To view the images:**
- Double-click on **eda_analysis.png** in VS Code
- Or open it from your folder

---

### 5.3 Run Step 3: Feature Engineering

1. Click on **step3_feature_engineering.py**
2. Click the **▶️ Play button**
3. Wait for it to complete
4. New files created:
   - **feature_engineering.png**
   - **bitcoin_features.csv**

---

### 5.4 Run Step 4: Build Models

1. Click on **step4_models.py**
2. Click the **▶️ Play button**
3. ⏳ This takes 1-2 minutes (training 4 models!)
4. Watch the results in the terminal:
```
🏆 BEST MODEL: Random Forest (Lowest MAE: $1,703.39)
```
5. New files created:
   - **model_comparison.png**
   - **model_performance_bar.png**
   - **model_predictions.csv**

---

## PART 6: View Your Results!

After running all 4 steps, you'll have these files:

| File | What it shows |
|------|--------------|
| **eda_analysis.png** | Price trends, volume, returns |
| **correlation_heatmap.png** | Feature correlations |
| **feature_engineering.png** | Technical indicators |
| **model_comparison.png** | All 4 models vs actual prices |
| **model_performance_bar.png** | Which model is best |

---

## 🔧 TROUBLESHOOTING COMMON ERRORS

### Error: "python is not recognized"
**Solution:** You didn't check "Add to PATH" during Python installation.
- Uninstall Python
- Install again, this time CHECK "Add Python to PATH"

### Error: "pip is not recognized"  
**Solution:** Same as above - reinstall Python with PATH checked

### Error: "No module named 'pandas'"
**Solution:** Run this in terminal:
```bash
pip install pandas
```

### Error: "No module named 'prophet'"
**Solution:** Prophet is tricky to install. Try:
```bash
pip install pystan==2.19.1.1
pip install prophet
```

If that fails, you can skip Prophet - the other 3 models will still work!

### Error: "Permission denied"
**Solution:** Run VS Code as Administrator:
- Right-click VS Code icon
- Select "Run as administrator"

### Error when downloading Bitcoin data
**Solution:** Your network might block Yahoo Finance. The code will generate sample data instead.

---

## 📁 Final Folder Structure

After running everything, your folder should look like:

```
bitcoin-prediction/
├── step1_data_collection.py      ← Code files
├── step2_eda.py
├── step3_feature_engineering.py
├── step4_models.py
├── Bitcoin_Price_Prediction.ipynb
├── README.md
│
├── bitcoin_data.csv              ← Data files
├── bitcoin_data_processed.csv
├── bitcoin_features.csv
├── model_predictions.csv
│
├── eda_analysis.png              ← Image files
├── correlation_heatmap.png
├── feature_engineering.png
├── model_comparison.png
└── model_performance_bar.png
```

---

## ✅ SUCCESS CHECKLIST

- [ ] Python installed and working
- [ ] VS Code installed with Python extension
- [ ] Project folder created
- [ ] All .py files downloaded and saved
- [ ] Libraries installed via pip
- [ ] Step 1 runs without errors
- [ ] Step 2 runs and creates images
- [ ] Step 3 runs and creates features
- [ ] Step 4 runs and shows model comparison
- [ ] All PNG images visible in folder

---

## 🎉 Congratulations!

You've successfully run a Machine Learning project on your laptop!

**Next steps:**
1. Upload to GitHub for your portfolio
2. Practice explaining what each step does
3. Try modifying the code (change parameters, add features)

---

## Need Help?

If you're stuck, copy the exact error message and ask me!
